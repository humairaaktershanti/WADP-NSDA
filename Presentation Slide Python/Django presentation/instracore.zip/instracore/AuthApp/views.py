from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import User

# -------------------------
# First-time Setup (Admin)
# -------------------------
def setup_view(request):
    if User.objects.filter(role='admin').exists():
        return redirect('login')  # Skip if admin already exists

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.error(request, "Passwords do not match")
            return redirect('setup')

        # Create superuser/admin
        user = User.objects.create_superuser(username=username, email=email, password=password1, role='admin')
        messages.success(request, "Admin account created. Please login.")
        return redirect('login')

    return render(request, 'setup.html')


# -------------------------
# Login View
# -------------------------
def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            messages.success(request, f"Welcome {user.username}!")
            return redirect('index')
        else:
            messages.error(request, "Invalid username or password")

    return render(request, 'login.html')


# -------------------------
# Logout View
# -------------------------
def logout_view(request):
    logout(request)
    messages.info(request, "Logged out successfully")
    return redirect('login')


# -------------------------
# Student Registration
# -------------------------
def register_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.error(request, "Passwords do not match")
            return redirect('register')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('register')

        # Create student account
        user = User.objects.create_user(username=username, email=email, password=password1, role='student')
        messages.success(request, "Account created successfully. Please login.")
        return redirect('login')

    return render(request, 'register.html')


# -------------------------
# Dashboard (Home Page)
# -------------------------
@login_required(login_url='login')
def index_view(request):
    return render(request, 'index.html', {'user': request.user})


# -------------------------
# Role-based access decorators
# -------------------------
from django.http import HttpResponseForbidden

def role_required(allowed_roles):
    def decorator(view_func):
        def wrapper(request, *args, **kwargs):
            if request.user.role not in allowed_roles:
                return HttpResponseForbidden("You do not have permission to view this page")
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator
