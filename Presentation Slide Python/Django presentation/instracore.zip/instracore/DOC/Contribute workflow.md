# Thinkori workflow:

## @humairaaktershanti:
  - Create Project name as instracore
  - Create app (AuthApp)
  - Register AuthApp
