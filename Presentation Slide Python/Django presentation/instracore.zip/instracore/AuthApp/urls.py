from django.urls import path
from AuthApp.views import *

urlpatterns = [
    # First-time setup (Admin)
    path('setup/', setup_view, name='setup'),

    # Authentication
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/', register_view, name='register'),

    # Dashboard / Home
    path('', index_view, name='index'),
]
