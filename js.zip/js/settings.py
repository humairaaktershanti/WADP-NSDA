# for custom user app
AUTH_USER_MODEL="myApp.customUserModel"

# for img
STATICFILES_DIRS=[
    BASE_DIR / "static",
]